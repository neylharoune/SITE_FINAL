package fr.istic.prg3;

import org.junit.Test;
import static org.junit.Assert.*;

public class BinaryTreeAlmostCompleteTest {

    @Test
    public void testConstructionParTableau() {
        int[] values = {100, 50, 150, 25, 75, 125, 175};
        BinaryTreeAlmostComplete tree = new BinaryTreeAlmostComplete(values);
        assertEquals(100, tree.rootValue);
        assertEquals(6, tree.nbDescendants);
        assertEquals(175, tree.getRightmostLowestNode().rootValue);
    }

    @Test
    public void testAddValueRemplitEnLargeur() {
        BinaryTreeAlmostComplete tree = new BinaryTreeAlmostComplete(1);
        tree.addValue(2); tree.addValue(3);
        tree.addValue(4); tree.addValue(5); tree.addValue(6); tree.addValue(7);

        assertEquals(2, tree.left.rootValue);
        assertEquals(3, tree.right.rootValue);
        assertEquals(5, tree.left.right.rootValue); 
    }

    @Test
    public void testGetRightmostLowestNode() {
        BinaryTreeAlmostComplete tree = new BinaryTreeAlmostComplete(new int[]{10, 5, 15, 3, 7, 12});
        BinaryTreeAlmostComplete last = tree.getRightmostLowestNode();
        assertEquals(12, last.rootValue);
        assertEquals(tree.right, last.up);
    }

    @Test
    public void testSiftUpRemonteJusquaRacine() {
        BinaryTreeAlmostComplete tree = new BinaryTreeAlmostComplete(new int[]{10, 20, 5});
        tree.getRightmostLowestNode().rootValue = 999;
        tree.getRightmostLowestNode().siftUp();
        assertEquals(999, tree.rootValue);
    }

    @Test
    public void testSiftDownDescendCorrectement() {
        BinaryTreeAlmostComplete tree = new BinaryTreeAlmostComplete(new int[]{1, 50, 40, 30, 20});
        tree.rootValue = 1;
        tree.siftDown();
        assertTrue(tree.rootValue >= 40 && tree.rootValue >= 30);
    }

    @Test
    public void testUpdateNumberOfDescendantsPropage() {
        BinaryTreeAlmostComplete tree = new BinaryTreeAlmostComplete(100);
        tree.addValue(50); tree.addValue(150);
        tree.addValue(25); tree.addValue(75);
        assertEquals(4, tree.nbDescendants);
        tree.right = null;
        tree.updateNumberOfDescendants();
        assertEquals(3, tree.nbDescendants);
    }
}