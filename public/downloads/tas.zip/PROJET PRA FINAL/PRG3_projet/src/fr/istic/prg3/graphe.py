import pandas as pd
import matplotlib.pyplot as plt

# Charge ton fichier CSV
df = pd.read_csv("performance_results.csv", sep=";", decimal=",")

aleatoire = df[df["Type"] == "Aleatoire"]
presque   = df[df["Type"] == "PresqueTrie"]

plt.figure(figsize=(15,7))

# Gauche → aléatoire
plt.subplot(1,2,1)
plt.loglog(aleatoire["Taille"], aleatoire["HeapTree(ms)"],   "o-",  label="HeapTree (arbre)",    markersize=10, linewidth=3, color="red")
plt.loglog(aleatoire["Taille"], aleatoire["ArrayList(ms)"],  "s-",  label="Arraylist",            markersize=10, linewidth=3, color="blue")
plt.loglog(aleatoire["Taille"], aleatoire["HeapArray(ms)"],  "^-",  label="HeapArray (tableau)", markersize=10, linewidth=3, color="green")
plt.title("Données aléatoires", fontsize=16)
plt.xlabel("Taille n")
plt.ylabel("Temps (ms)")
plt.legend(fontsize=12)

# Droite → presque triées
plt.subplot(1,2,2)
plt.loglog(presque["Taille"], presque["HeapTree(ms)"],   "o-",  label="HeapTree (arbre)",    markersize=10, linewidth=3, color="red")
plt.loglog(presque["Taille"], presque["ArrayList(ms)"],  "s-",  label="Arraylist",            markersize=10, linewidth=3, color="blue")
plt.loglog(presque["Taille"], presque["HeapArray(ms)"],  "^-",  label="HeapArray (tableau)", markersize=10, linewidth=3, color="green")
plt.title("Presque triées (10 % aléatoire)", fontsize=16)
plt.xlabel("Taille n")

plt.legend(fontsize=12)

plt.suptitle("PRA 2025/2026 – Comparaison des tris par tas", fontsize=18, fontweight="bold")
plt.tight_layout()
plt.savefig("Figure_4_PRA_mes_resultats.png", dpi=300, bbox_inches='tight')
plt.savefig("Figure_4_PRA_mes_resultats.pdf", bbox_inches='tight')
plt.show()

print("Graphiques créés ! Regarde les fichiers :")
print("→ Figure_4_PRA_mes_resultats.png")
print("→ Figure_4_PRA_mes_resultats.pdf")