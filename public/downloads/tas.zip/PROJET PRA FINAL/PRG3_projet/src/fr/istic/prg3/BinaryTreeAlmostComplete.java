/**
 * 
 */
package fr.istic.prg3;

import java.util.Objects;



/**
 * @version 1.0
 *
 */
public class BinaryTreeAlmostComplete {
	
	protected int rootValue;
	protected BinaryTreeAlmostComplete left;
	protected BinaryTreeAlmostComplete right;
	protected BinaryTreeAlmostComplete up;
	protected int nbDescendants;
	
	
	public BinaryTreeAlmostComplete(int value) {
		this(value, null);
	}
	
	
	public BinaryTreeAlmostComplete(int[] values) {
		if (values == null || values.length == 0) {
			throw new IllegalArgumentException("ne peut pas etre null oups...");
		}
		
		this.rootValue = values[0]; 
		this.left = null;
		this.right = null;
		this.up = null; 
		
		this.nbDescendants = 0; 
		
		for (int i = 1; i < values.length; i++) {
			this.addValue(values[i]);
		}
	}
	
	
	public BinaryTreeAlmostComplete(int value, BinaryTreeAlmostComplete parent) {
		this.rootValue = value;
		this.left = null;
		this.right = null;
		this.up = parent;
		this.updateNumberOfDescendants();
	}
	
	
	
	
	
	
	public void addValue(int value) {
		if (Objects.isNull(this.left)) {
			this.left = new BinaryTreeAlmostComplete(value, this);
			this.updateNumberOfDescendants();
		}
		else {
			if (Objects.isNull(this.right)) {
				this.right = new BinaryTreeAlmostComplete(value, this);
				this.updateNumberOfDescendants();
			}
			else {
				// both left and right exist
				int nbDescLeft = this.left.nbDescendants;
				if (getLevels(nbDescLeft) == getLevels(nbDescLeft + 1)) {
					// the lowest level of left child is not full
					this.left.addValue(value);
				}
				else {
					// the lowest level of left child is full
					int nbDescRight = this.right.nbDescendants;
					if (nbDescLeft > nbDescRight) {
						// the lowest level of left child is full, AND the lowest level of right child is not full
						this.right.addValue(value);
					}
					else {
						// both left and right child are full and have the same level
						this.left.addValue(value);
					}
				}
			}
		}
	}
	
	
	
	protected static int getLevels(int n) {
		return (int)(Math.log(n + 1) / Math.log(2));
	}
	
	
	protected BinaryTreeAlmostComplete getRightmostLowestNode() {
		if (this.left == null && this.right == null) {
			return this;
		}
		//leftiscomplete renvoie false si egalité, dcp pas complet
		boolean leftIsComplete = getLevels(this.left.nbDescendants) 
							< getLevels(this.left.nbDescendants + 1);

		if (!leftIsComplete) {
			// fils gauche incomplet → le dernier nœud est dans le sous-arbre gauche
			return this.left.getRightmostLowestNode();
		}

		// fils gauche complet
		if (this.right == null) {
			return this.left.getRightmostLowestNode();
		}

		int leftLevels = getLevels(this.left.nbDescendants);
		int rightLevels = this.right != null ? getLevels(this.right.nbDescendants) : -1;

		if (leftLevels != rightLevels) {
			// fils droit a un niveau de moins → dernier nœud est encore dans le gauche
			return this.left.getRightmostLowestNode();
		} else {
			// fils droit a le même niveau → dernier nœud est dans le droit
			return this.right.getRightmostLowestNode();
		}
	}

	public void siftDown() {
		BinaryTreeAlmostComplete current = this;

		while (current.left != null) {
			// Par défaut, on suppose que le fils gauche est le plus grand
			BinaryTreeAlmostComplete largestChild = current.left;

			// Si le fils droit existe et est plus grand, on le choisit
			if (current.right != null && current.right.rootValue > largestChild.rootValue) {
				largestChild = current.right;
			}

			// Si le parent est déjà plus grand ou égal → on arrête
			if (current.rootValue >= largestChild.rootValue) {
				break;
			}

			// Échange avec le fils le plus grand
			int temp = current.rootValue;
			current.rootValue = largestChild.rootValue;
			largestChild.rootValue = temp;

			// Continue avec le fils
			current = largestChild;
		}
	}
		
    
	public void siftUp() {
		BinaryTreeAlmostComplete child = this;
		
		while (child.up != null && child.rootValue > child.up.rootValue) {
			// Échange des valeurs
			int temp = child.rootValue;
			child.rootValue = child.up.rootValue;
			child.up.rootValue = temp;
			
			child = child.up;  // remonte
		}
	}
	
	
	
	public String toString() {
		return this.toString("");
	}

	public String toString(String offset) {
        StringBuilder sb = new StringBuilder();

        // Affichage de la RACINE (avec l'offset actuel)
        sb.append(offset);
        sb.append(this.rootValue)
        .append(" (")
        .append(this.nbDescendants)
        .append(" descendants)\n"); 

        //  Appel récursif sur le fils GAUCHE
        if (Objects.nonNull(this.left)) {
            sb.append(this.left.toString(offset + "  ")); 
        }

        //  Appel récursif sur le fils DROIT
        if (Objects.nonNull(this.right)) {
            sb.append(this.right.toString(offset + "  "));
        }

        return sb.toString();
    }
	
	
	
	protected void updateNumberOfDescendants() {
		this.nbDescendants = 0;
		if (Objects.nonNull(this.left)) {
			this.nbDescendants += 1 + this.left.nbDescendants;
		}
		if (Objects.nonNull(this.right)) {
			this.nbDescendants += 1 + this.right.nbDescendants;
		}
		if (Objects.nonNull(this.up)) {
			up.updateNumberOfDescendants();
		}
	}


	
public static void main(String[] args) {
    int[] t = {109, 107, 111, 112, 103, 104, 110, 101, 106, 102, 108, 105};
    
    BinaryTreeAlmostComplete tree = new BinaryTreeAlmostComplete(t);
    
    System.out.println(tree);
    System.out.println("Dernier nœud = " + tree.getRightmostLowestNode().rootValue);
    
    // CORRIGÉ : on met 999 sur le DERNIER nœud, pas sur tree.left !
    tree.getRightmostLowestNode().rootValue = 999;
    tree.getRightmostLowestNode().siftUp();
    System.out.println("Après 999 sur dernier + siftUp() → racine = " + tree.rootValue);

	System.out.println(tree);

    tree.rootValue = 1;
    tree.siftDown();
    System.out.println("Après 1 à la racine + siftDown() → racine = " + tree.rootValue);
}

}