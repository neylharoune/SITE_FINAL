/**
 * 
 */
package fr.istic.prg3;

import java.util.Objects;



/**
 * @version 1.0
 *
 */
public class HeapTree extends BinaryTreeAlmostComplete implements Heap {
	
	public HeapTree(int value) {
		super(value);
	}
	
	
	public HeapTree(int value, HeapTree parent) {
		super(value,parent);
	}
	
	
	public HeapTree(int[] tab) {
		super(tab);

	}
	
	
	@Override
	public void addValue(int value) {
		super.addValue(value);
		BinaryTreeAlmostComplete newnode= super.getRightmostLowestNode();

		newnode.siftUp();
	}
	
	
	@Override
	public int extractMax() {
		int max = rootValue;

		if (Objects.isNull(this.left)) {
			// Cas : tas vide ou un seul élément → on retourne la valeur
			return max;
		}

		// Cas normal : au moins 2 éléments
		BinaryTreeAlmostComplete last = getRightmostLowestNode();
		rootValue = last.rootValue;

		// Suppression du dernier nœud
		BinaryTreeAlmostComplete parent = last.up;
			if (parent.left == last) {
				parent.left = null;
			} else {
				parent.right = null;
			}
			parent.updateNumberOfDescendants(); // met à jour toute la chaîne

		siftDown();
		return max;
	}
	
	
	public int getMax() {
		return this.rootValue;
	}
	
	
	public static int[] heapsort(int[] unsortedValues) {
		if (unsortedValues == null || unsortedValues.length <= 1) {
			return unsortedValues != null ? unsortedValues.clone() : new int[0];
		}

		HeapTree heap = new HeapTree(unsortedValues);
		int[] result = new int[unsortedValues.length];

		for (int i = result.length - 1; i >= 0; i--) {
			result[i] = heap.extractMax();  // on remplit de la fin vers le début → ordre croissant direct
		}

		return result;
	}
	

	/**
	 * @param args
	 */
	

	public static void main(String[] args) {
    int[] treeValues = {109, 107, 111, 112, 103, 104, 110, 101, 106, 102, 108, 105};

   	HeapTree heap = new HeapTree(treeValues);
    System.out.println("Max = " + heap.getMax());
    System.out.println("extractMax() = " + heap.extractMax());
    System.out.println("Nouveau max = " + heap.getMax());

    System.out.println("\n--- HEAPSORT ---");
    int[] sorted = HeapTree.heapsort(treeValues);
    System.out.print("Trié : ");
    for (int v : sorted) System.out.print(v + " ");
    System.out.println("\n→ 101 102 103 104 105 106 107 108 109 110 111 112");
}
}
