package fr.istic.prg3;

/**
 * @version 1.0
 *
 */
public class HeapArray implements Heap {
	
	protected int[] values;
	protected int size;
	
	public HeapArray(int[] valuesArray) {
		if (valuesArray == null) {
			values = new int[0];
			size = 0;
		} else {
			values = valuesArray.clone();
			size = values.length;
			//ajout par la fin puis remonter avec siftup
			heapify();
			}
		
	}
	
	
	public void addValue(int newValue) {
		if (size == values.length) {
			// si plus de place
			int[] newValues = new int[values.length * 2];
			System.arraycopy(values, 0, newValues, 0, size);
			values = newValues;
		}
		values[size] = newValue;
		size++;
		siftUp(size - 1);
	}
	
	
	public int getMax() {
		if (size == 0) {
			throw new IllegalStateException("Heap is empty");
		}
		return values[0];
	}
	
	
	public int extractMax() {
		if (size == 0) {
			throw new IllegalStateException("Heap is empty");
		}
		if(size == 1 ){
			return values[0];
		}
		int max = values[0];
		values[0] = values[size - 1];
		size--;
		if (size > 0) {
			heapifyDown();
		}
		return max;
	}

	public void heapify() {
		
		for (int i=size-1; i>=0; i--) {
			siftUp(i); 
		}	
	}
	
	
	protected void heapifyDown() {
		siftDown(0);
	}
	
	
	public static int[] heapsort(int[] unsortedValues) {
		if (unsortedValues == null || unsortedValues.length <= 1) {
			return unsortedValues != null ? unsortedValues.clone() : new int[0];
		}

		HeapArray heap = new HeapArray(unsortedValues);
		int[] result = new int[unsortedValues.length];

		for (int i = result.length - 1; i >= 0; i--) {
			result[i] = heap.extractMax();
		}

		return result;
	}
	
	
	
	protected int indexLeft(int position) {
		return 2 * position + 1;
	}
	
	
	protected int indexRight(int position) {
		return 2 * position + 2;
	}
	
	
	protected int indexUp(int position) {
		return (position - 1) / 2;
	}
	
	
	public void siftDown() {
		this.siftDown(0);
	}
	
	
	protected void siftDown(int position) {
		int cursor = position;
		int left = indexLeft(position);
		
		while (left < size) {
			int largest = cursor ; 
			int right = indexRight(cursor); 
			
			if (values[left] > values[largest]) {
				largest = left ; 
			}
			
			if (right <size && values[right] > values[largest]) {
				largest = right ; 
			}
			
			if (largest == cursor ) {
				break; 
			}
			
			swap(cursor, largest); 
			cursor = largest ;
			left = indexLeft(cursor); 
		}
		
	}
	


	
	
	public void siftUp() {
		this.siftUp(this.size - 1);
	}
	
	 
	protected void siftUp(int position) {
		int cursor = position;
		
		while (cursor > 0) {
			int parent = indexUp(cursor);
			
			if (values[cursor] > values[parent]) {
				swap(cursor, parent);
				cursor = parent; // On monte à l'index du parent pour la prochaine itération
			} else {
				break; // Le tas est rétabli
			}
		}
	}
	
	
	protected void swap(int index1, int index2) {
		int temp = values[index1];
		values[index1] = values[index2];
		values[index2] = temp;
	}
	
	
	protected void swapIfGreaterAndSiftUp(int index1, int index2) {
		if (values[index1] > values[index2]) {
			swap(index1, index2);
			siftUp(index2);
		}
	}
	
	
	protected void swapIfLowerAndSiftDown(int index1, int index2) {
		if (values[index1] < values[index2]) {
			swap(index1, index2);
			siftDown(index2);
		}
	}
	
	
	public String toString() {
		return toString("");
	}
	
	
	public String toString(String offset) {
		return toString(0, offset);
	}
	
	private String toString(int index, String offset) {
		if (index >= size) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		sb.append(offset).append(values[index]).append("\n");
		sb.append(toString(indexLeft(index), offset + "  "));
		sb.append(toString(indexRight(index), offset + "  "));
		return sb.toString();
	}
	
	
	
	

	public static void main(String[] args) {
		int[] treeValues = {109, 107, 111, 112, 103, 104, 110, 101, 106, 102, 108, 105};

		HeapArray heap = new HeapArray(treeValues);
		System.out.println(heap);
		System.out.println("Max = " + heap.getMax());
		System.out.println("extractMax() = " + heap.extractMax());
		System.out.println("Nouveau max = " + heap.getMax());
		System.out.println("extractMax() = " + heap.extractMax());
		System.out.println("extractMax() = " + heap.extractMax());
		System.out.println("extractMax() = " + heap.extractMax());
		

		System.out.println("\n--- HEAPSORT ---");
		int[] sorted = HeapArray.heapsort(treeValues);
		System.out.print("Trié : ");
	for (int v : sorted) System.out.print(v + " ");
		System.out.println("\n→ 101 102 103 104 105 106 107 108 109 110 111 112");
	}
}