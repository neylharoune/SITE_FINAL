package fr.istic.prg3;

/**
 * @version 1.0
 *
 */
public interface Heap {
	
	/**
	 * Adds a new value to the heap.
	 * This methods does nothing is the value is already present.
	 * 
	 * @param newValue	the value to add
	 */
	public void addValue(int newValue);
	
	
	public int extractMax();
	
	
	public int getMax();
	
	
	public static int[] heapsort(int[] unsortedValues) {
			if (unsortedValues == null || unsortedValues.length <= 1) {
				return unsortedValues != null ? unsortedValues.clone() : new int[0];
			}

			HeapTree heap = new HeapTree(unsortedValues);
			
			int[] result = new int[unsortedValues.length];

			for (int i = result.length - 1; i >= 0; i--) {
				result[i] = heap.extractMax();  // on remplit de la fin vers le début → ordre croissant direct
			}

			return result;
		}
	
	
	public void siftDown();
	
	
	public void siftUp();

}
