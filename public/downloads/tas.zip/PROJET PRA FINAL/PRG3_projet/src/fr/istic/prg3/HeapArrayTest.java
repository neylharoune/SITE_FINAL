package fr.istic.prg3;

import org.junit.Test;
import static org.junit.Assert.*;

public class HeapArrayTest {

    @Test
    public void testConstructionParTableauFaitHeapify() {
        int[] data = {10, 50, 30, 90, 20, 80, 40};
        HeapArray heap = new HeapArray(data);
        assertEquals(90, heap.getMax());
    }

    @Test
    public void testAddValueRedimensionneEtSiftUp() {
        HeapArray heap = new HeapArray(new int[]{50, 30});
        for (int i = 0; i < 20; i++) {
            heap.addValue(i);
        }
        heap.addValue(999);
        assertEquals(999, heap.getMax());
        assertTrue(heap.size >= 22); // redimensionnement
    }

    @Test
    public void testExtractMaxMaintientProprieteTas() {
        HeapArray heap = new HeapArray(new int[]{90, 10, 80, 40, 50});
        assertEquals(90, heap.getMax());
        assertEquals(90, heap.extractMax());
        assertEquals(80, heap.extractMax());
        assertEquals(50, heap.extractMax());

    }

    @Test
    public void testHeapsortTrieCorrectement() {
        int[] data = {64, 12, 87, 33, 98, 22, 76, 45, 55};
        int[] sorted = HeapArray.heapsort(data);
        int[] expected = {12, 22, 33, 45, 55, 64, 76, 87, 98};
        assertArrayEquals(expected, sorted);
    }

    @Test
    public void testTasVideEtException() {
        HeapArray heap = new HeapArray(new int[0]);
        assertThrows(IllegalStateException.class, heap::getMax);
    }
}