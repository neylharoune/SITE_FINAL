package fr.istic.prg3;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class PerformanceAnalysis {

    public static void main(String[] args) {
        // Les tailles a  tester
        int[] sizes = {10, 100, 1000, 10000, 100000, 1000000}; 
        
        String csvFile = "performance_results.csv";

        System.out.println("Lancement de l'analyse... Ecriture dans " + csvFile);

        // Le try-with-resources ferme automatiquement le fichier a  la fin
        try (PrintWriter writer = new PrintWriter(new FileWriter(csvFile))) {
            
            // Ã‰criture de l'en-tete du CSV (avec une colonne Type en plus)
            writer.println("Type;Taille;HeapTree(ms);ArrayList(ms);HeapArray(ms)");

            // 1. Analyse Aleatoire
            System.out.println("--- Traitement : LISTES ALEATOIRES ---");
            for (int size : sizes) {
                runTest(size, false, writer);
            }

            // 2. Analyse Presque Triée
            System.out.println("--- Traitement : LISTES PRESQUE TRIEES ---");
            for (int size : sizes) {
                runTest(size, true, writer);
            }
            
            System.out.println("Terminé ! Résultats sauvegardés dans " + csvFile);

        } catch (IOException e) {
            System.err.println("Erreur lors de l'écriture du fichier : " + e.getMessage());
        }
    }

    /**
     * ExÃ©cute le test et Ã©crit une ligne dans le fichier CSV via le writer
     */
    public static void runTest(int size, boolean almostSorted, PrintWriter writer) {
        // 1. Generation des donnees
        int[] dataForHeapTree;
        ArrayList<Integer> dataForJava;
        int[] dataForHeapArray; 

        if (almostSorted) {
            dataForHeapTree = generateAlmostSorted(size, 0.10);
        } else {
            dataForHeapTree = generateRandom(size);
        }

        // Conversion pour ArrayList
        dataForJava = new ArrayList<>(size);
        for (int val : dataForHeapTree) {
            dataForJava.add(val);
        }
        
        // Copie pour HeapArray
        dataForHeapArray = dataForHeapTree.clone();

        // 2. Mesure HeapTree
        long start = System.nanoTime();
        HeapTree.heapsort(dataForHeapTree);
        long end = System.nanoTime();
        double durationHeapTree = (end - start) / 1_000_000.0;

        // 3. Mesure ArrayList
        start = System.nanoTime();
        Collections.sort(dataForJava);
        end = System.nanoTime();
        double durationJava = (end - start) / 1_000_000.0;

        // 4. Mesure HeapArray
        start = System.nanoTime();
        HeapArray.heapsort(dataForHeapArray);
        end = System.nanoTime();
        double durationHeapArray = (end - start) / 1_000_000.0;
        

        // DÃ©finition du type pour le CSV
        String type = almostSorted ? "PresqueTrie" : "Aleatoire";

        // Formatage de la ligne CSV
        // Format: Type;Taille;HeapTree;ArrayList;HeapArray
        String line = String.format("%s;%d;%.3f;%.3f;%.3f", 
                                    type, size, durationHeapTree, durationJava, durationHeapArray);
        
        // Ã‰criture dans le fichier
        writer.println(line);
        
        // Ã‰criture dans la console (pour suivre l'avancement)
        System.out.println("Ecriture : " + line);
        
        // Nettoyage mÃ©moire
        System.gc();
    }

    public static int[] generateRandom(int size) {
        Random rand = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = rand.nextInt(size * 10);
        }
        return arr;
    }

    public static int[] generateAlmostSorted(int size, double swapRatio) {
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = i;
        }
        Random rand = new Random();
        int numberOfSwaps = (int) (size * swapRatio);
        for (int k = 0; k < numberOfSwaps; k++) {
            int i = rand.nextInt(size);
            int j = rand.nextInt(size);
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
        return arr;
    }
}