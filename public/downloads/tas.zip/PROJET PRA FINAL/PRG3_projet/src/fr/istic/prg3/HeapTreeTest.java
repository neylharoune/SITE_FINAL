package fr.istic.prg3;

import org.junit.Test;
import static org.junit.Assert.*;

public class HeapTreeTest {

    @Test
    public void testAddValueFaitSiftUp() {
        HeapTree heap = new HeapTree(10);
        heap.addValue(50);
        assertEquals(50, heap.getMax());
        heap.addValue(30);
        assertEquals(50, heap.getMax());
        heap.addValue(100);
        assertEquals(100, heap.getMax());
    }

    @Test
    public void testExtractMaxSupprimeDernierNoeudEtSiftDown() {
        HeapTree heap = new HeapTree(new int[]{40, 90, 50, 80, 20, 70, 30});
        assertEquals(90, heap.extractMax());
        assertEquals(80, heap.getMax());
        assertEquals(80, heap.extractMax());
        assertTrue(heap.getMax() <= 70);
    }

    @Test
    public void testExtractMaxSurUnSeulElement() {
        HeapTree heap = new HeapTree(999);
        assertEquals(999, heap.extractMax());
        // ne plante pas → OK
    }

    @Test
    public void testHeapsortTrieEnOrdreCroissant() {
        int[] data = {109, 107, 111, 112, 103, 104, 110, 101, 106, 102, 108, 105};
        int[] sorted = HeapTree.heapsort(data);
        int[] expected = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112};
        assertArrayEquals(expected, sorted);
    }

    @Test
    public void testStructurePresqueCompletePreserveeApresExtract() {
        HeapTree heap = new HeapTree(new int[]{100, 50, 150, 25, 75, 125, 175});
        heap.extractMax();
        assertNotNull(heap.left);
        assertNotNull(heap.right);
        assertTrue(heap.left.nbDescendants >= heap.right.nbDescendants);
    }
}