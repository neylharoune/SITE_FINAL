#include <iostream>
#include <string>
#include <map>
#include <algorithm>
#include <random>
#include <array>
#include <vector>



std::map<std::string, int> liste_valeur = {
    {"As", 1},
    {"2", 2},
    {"3", 3},
    {"4", 4},
    {"5", 5},
    {"6", 6},
    {"7", 7},
    {"8", 8},
    {"9", 9},
    {"10", 10},
    {"Valet", 11},
    {"Dame", 12},
    {"Roi", 13},
    {"", 50}
};

    std::map<std::string, std::string> type_symbole = {
        {"coeur", u8"\u2665"},
        {"pique", u8"\u2660"},
        {"trefle", u8"\u2663"},
        {"carreau", u8"\u2666"}
    };

std::array<std::string, 4> liste_type = {"\u2665", "\u2660", "\u2663", "\u2666"};

struct carte_tab {
    std::string valeur;
    std::string type;
    bool util;
};

struct carte {
    carte_tab crt;
    carte* suiv;
};

struct joueur {
    std::string nom;
    carte_tab cartes[14];
    carte_tab brelan[14];
    carte_tab suite[14];
    carte_tab carre[14];
    carte_tab paire[14];
    int point;
};

using Jeu = carte*;
using defausse = carte*;




Jeu tableau_liste(carte_tab* tab) {
    Jeu j = nullptr;
    for (int i = 0; i < 104; ++i) {
        carte* p = new carte;
        p->crt.valeur = tab[i].valeur;
        p->crt.type = tab[i].type;
        p->suiv = j;
        j = p;
    }
    return j;
}

Jeu CreeJeu() {
    std::string tab[] = {"As", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valet", "Dame", "Roi"};
    carte_tab* jeu_de_carte;
    jeu_de_carte = new carte_tab[104];
    int l = 0;
    for (int k = 0; k < 2; ++k) {
        for (int i = 0; i < sizeof(tab) / sizeof(tab[0]); ++i) {
            for (int j = 0; j < liste_type.size(); ++j) {
                jeu_de_carte[l].valeur = tab[i];
                jeu_de_carte[l].type = liste_type[j];
                ++l;
            }
        }
    }

    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(jeu_de_carte, jeu_de_carte + 104, g);

    Jeu jeu = tableau_liste(jeu_de_carte);
    delete[] jeu_de_carte;
    return jeu;
}

carte_tab pop(Jeu& jeu_de_carte) {
    if (jeu_de_carte != nullptr) {
        carte* p;
        p = jeu_de_carte;
        jeu_de_carte = jeu_de_carte->suiv;
        carte_tab c;
        c.valeur = p->crt.valeur;
        c.type = p->crt.type;
        delete (p);
        return (c);
    } else {
        carte_tab c;
        c.valeur = "";
        c.type = "";
        return c;
    }
}


void distribuer(Jeu& jeu, int nbr, joueur*& j) {
    for (int k = 0; k < 14; ++k) {
        for (int i = 0; i < nbr; ++i) {
            carte_tab c = pop(jeu);
            j[i].cartes[k].valeur = c.valeur;
            j[i].cartes[k].type = c.type;
        }
    }

    
}

void afficher_cartes_joueur_organiser(const joueur& j) {
    const int taille = 14;

    // Allocation dynamique des tableaux pour chaque type de carte
    carte_tab* coeur = new carte_tab[taille];
    carte_tab* carreau = new carte_tab[taille];
    carte_tab* pique = new carte_tab[taille];
    carte_tab* trefle = new carte_tab[taille];

    // Variables pour garder la trace du nombre de cartes de chaque type
    int coeur_count = 0;
    int carreau_count = 0;
    int pique_count = 0;
    int trefle_count = 0;

    // Tri des cartes du joueur par type
    for (int i = 0; i < taille; ++i) {
        if (j.cartes[i].type == "\u2665") {
            coeur[coeur_count++] = j.cartes[i];
        } else if (j.cartes[i].type == "\u2666") {
            carreau[carreau_count++] = j.cartes[i];
        } else if (j.cartes[i].type == "\u2660") {
            pique[pique_count++] = j.cartes[i];
        } else if (j.cartes[i].type == "\u2663") {
            trefle[trefle_count++] = j.cartes[i];
        }
    }

    if (coeur_count > 0) {
        std::cout << type_symbole["coeur"] << " ";
        for (int i = 0; i < coeur_count; ++i) {
            std::cout << coeur[i].valeur << " ";
        }
        std::cout << std::endl;
    }

    if (carreau_count > 0) {
        std::cout << type_symbole["carreau"] << " ";
        for (int i = 0; i < carreau_count; ++i) {
            std::cout << carreau[i].valeur << " ";
        }
        std::cout << std::endl;
    }

    if (pique_count > 0) {
        std::cout << type_symbole["pique"] << " ";
        for (int i = 0; i < pique_count; ++i) {
            std::cout << pique[i].valeur << " ";
        }
        std::cout << std::endl;
    }

    if (trefle_count > 0) {
        std::cout <<type_symbole["trefle"] << " ";
        for (int i = 0; i < trefle_count; ++i) {
            std::cout << trefle[i].valeur << " ";
        }
        std::cout << std::endl;
    }

    // Libération de la mémoire allouée dynamiquement
    delete[] coeur;
    delete[] carreau;
    delete[] pique;
    delete[] trefle;
}

void afficher_cartes_joueur(const joueur& j) {
    std::cout << j.nom << " : " ;
    for (int i = 0; i < 14; ++i) {
        std::cout << j.cartes[i].valeur << " " << j.cartes[i].type << " " << j.cartes[i].util<<  "|";
    }
    std::cout << std::endl;
}

void afficher_cartes_restantes(const Jeu& jeu) {
    std::cout << "Les cartes restantes sont les suivantes : " << std::endl;
    Jeu p = jeu;
    while (p != nullptr) {
        std::cout << p->crt.valeur << " " << p->crt.type << std::endl;
        p = p->suiv;
    }
}

void initialiser_defausse(Jeu& jeu_de_carte, defausse& defausse_pile) {
    carte_tab premiere_carte = pop(jeu_de_carte);

    carte* nv_defausse = new carte;
    nv_defausse->crt.type = premiere_carte.type;
    nv_defausse->crt.valeur = premiere_carte.valeur;
    nv_defausse->suiv = defausse_pile;

    defausse_pile = nv_defausse;
}

carte_tab piocher_carte(Jeu& jeu, defausse& defausse_pile) {
    if (defausse_pile != nullptr) {
        std::cout << "La carte de la défausse est : " << defausse_pile->crt.valeur << " " << defausse_pile->crt.type << std::endl;
    } else {
        std::cout << "La défausse est vide." << std::endl;
    }

    char choix;
    std::cout << "Voulez-vous piocher la carte de la défausse (D) ou la première carte des cartes restantes (C) ? ";
    std::cin >> choix;

    if (choix == 'D' || choix == 'd') {
        if (defausse_pile != nullptr) {
            carte_tab carte_piochee;
            carte_piochee.valeur = defausse_pile->crt.valeur;
            carte_piochee.type = defausse_pile->crt.type;
            carte* temp = defausse_pile;
            defausse_pile = defausse_pile->suiv;
            delete temp;

            std::cout << "Vous avez pioché la carte de la défausse : " << carte_piochee.valeur << " " << carte_piochee.type << std::endl;
            return carte_piochee;
        } else {
            std::cout << "La défausse est vide, vous ne pouvez pas piocher la carte de la défausse !" << std::endl;
        }
    } else if (choix == 'C' || choix == 'c') {
        carte_tab nouvelle_carte = pop(jeu);
        std::cout << "Vous avez pioché la première carte des cartes restantes : " << nouvelle_carte.valeur << "  " << nouvelle_carte.type << std::endl;
        return nouvelle_carte;
    } else {
        std::cout << "Choix invalide. Veuillez choisir D pour piocher la carte de la défausse ou C pour piocher la première carte des cartes restantes." << std::endl;
    }

    return {"", "", false};
}



void trier_liste(joueur& j, int nbr) {
    std::sort(j.cartes, j.cartes + 14, [](const carte_tab& a, const carte_tab& b) {
        return liste_valeur[a.valeur] < liste_valeur[b.valeur];
    });
}



void liste_brelan(joueur& j) {
   trier_liste(j,13);
    int index = 0;
    int cpt = 0;
    while (index < 12) {
        if(j.cartes[index].valeur != ""){
            if ( !j.cartes[index].util && !j.cartes[index+1].util &&  !j.cartes[index+2].util   &&
                liste_valeur[j.cartes[index].valeur] == liste_valeur[j.cartes[index + 1].valeur] && 
                liste_valeur[j.cartes[index].valeur] == liste_valeur[j.cartes[index + 2].valeur] && 
                 j.cartes[index].type != j.cartes[index + 1].type && 
                j.cartes[index+ 1].type != j.cartes[index + 2].type && 
                j.cartes[index].type != j.cartes[index + 2].type) {
                j.brelan[cpt] = j.cartes[index];
                j.brelan[cpt + 1] = j.cartes[index + 1];
                j.brelan[cpt + 2] = j.cartes[index + 2];
                cpt = cpt + 3;
                
                j.cartes[index].util = true;
                j.cartes[index+1].util = true;
                j.cartes[index+2].util = true;
            }
            index++;
        }else{
            index++;
        }
    }
}

void liste_suite(joueur& j) {
    trier_liste(j, 14);
    int nb_suite = 0; // Compteur pour le nombre de tierces trouvées

    for (int i = 0; i < 12; ++i) {
        if (j.cartes[i].util) continue; // Passer à la prochaine carte si celle-ci est déjà utilisée
        for (int y = i + 1; y < 13; ++y) {
            if (j.cartes[y].util) continue;
            for (int k = y + 1; k < 14; ++k) {
                if (j.cartes[k].util) continue;

                // Vérifier si la valeur des cartes forme une tierce
                if (liste_valeur[j.cartes[i].valeur] + 1 == liste_valeur[j.cartes[y].valeur] &&
                    liste_valeur[j.cartes[y].valeur] + 1 == liste_valeur[j.cartes[k].valeur] &&
                    j.cartes[i].type == j.cartes[y].type && j.cartes[y].type == j.cartes[k].type) {

                    // Marquer les cartes comme utilisées
                    j.cartes[i].util = true;
                    j.cartes[y].util = true;
                    j.cartes[k].util = true;

                    // Ajouter les cartes à la tierce
                    j.suite[nb_suite++] = j.cartes[i];
                    j.suite[nb_suite++] = j.cartes[y];
                    j.suite[nb_suite++] = j.cartes[k];

                    int cpt = 1;
                    // Recherche de cartes supplémentaires pour compléter la tierce
                    for (int l = k + 1; l < 14; ++l) {
                        if (!j.cartes[l].util &&
                            liste_valeur[j.cartes[k].valeur] + cpt == liste_valeur[j.cartes[l].valeur] &&
                            j.cartes[y].type == j.cartes[l].type) {
                            j.suite[nb_suite++] = j.cartes[l];
                            j.cartes[l].util = true;
                            cpt++;
                        }
                    }

                    // Sortir des boucles intérieures pour éviter de doubler les tierces
                    y = k = 14;
                }
            }
        }
    }
}




void liste_carre(joueur& j) {
    trier_liste(j, 13); 

    for (int index = 0; index < 11; ++index) {
        // Vérifiez si quatre cartes consécutives ont la même valeur
        if (!j.cartes[index].util &&
        (j.cartes[index].valeur == j.cartes[index + 1].valeur &&
        j.cartes[index].valeur == j.cartes[index + 2].valeur &&
        j.cartes[index].valeur == j.cartes[index + 3].valeur) &&
        (j.cartes[index].type != j.cartes[index + 1].type &&
        j.cartes[index].type != j.cartes[index + 2].type &&
        j.cartes[index].type != j.cartes[index + 3].type) &&
        (j.cartes[index + 1].type != j.cartes[index + 2].type &&
        j.cartes[index + 1].type != j.cartes[index + 3].type &&
        j.cartes[index + 2].type != j.cartes[index + 3].type)) {

            // Ajoutez les quatre cartes au carré
            j.carre[0] = j.cartes[index];
            j.carre[1] = j.cartes[index + 1];
            j.carre[2] = j.cartes[index + 2];
            j.carre[3] = j.cartes[index + 3];

            // Marquez les cartes comme utilisées
            j.cartes[index].util = true;
            j.cartes[index + 1].util = true;
            j.cartes[index + 2].util = true;
            j.cartes[index + 3].util = true;

            break; // Sortez de la boucle une fois que le carré est trouvé
        }
    }
}



int nombre_total_cartes(joueur& j) {
    int total = 0;
    
    for (int i = 0; i < 14; i++) {
        if (j.paire[i].valeur != "") {
            total += 1; 
        }
    }
    
    for (int i = 0; i < 14; i++) {
        if (j.brelan[i].valeur != "") {
            total += 1; 
        }
    }
    
    for (int i = 0; i < 14; i++) {
        if (j.suite[i].valeur != "") {
            total += 1; 
        }
    }
    
    for (int i = 0; i < 14; i++) {
        if (j.carre[i].valeur != "") {
            total += 1; 
        }
    }
    
    return total;
}



void completer_as(joueur& j) {
    trier_liste(j, 13);
    bool twelve_found = false;
    int douz = -1; // 
    bool thirteen_found = false;
    int traiz = -1; // 
    bool as_found = false;
    int as_index = -1; // 
    
    // recherche un as non utilisé
    for (int i = 0; i < 13; ++i) {
        if (liste_valeur[j.cartes[i].valeur] == 1 && !j.cartes[i].util) {
            as_found = true;
            as_index = i;
            break;
    }
}

    int nbr = 0;
    for (int k = 0; k < 14; k++) {
        if (j.suite[k].valeur != "")
            nbr++;
    }
    
    if (nbr > 0 && liste_valeur[j.suite[nbr - 1].valeur] == 13 && as_found && j.cartes[as_index].type == j.suite[nbr - 1].type) {
        j.suite[nbr] = j.cartes[as_index];
        j.cartes[as_index].util = true;
    }

    //recherche dame non utilisée
    for (int i = 0; i < 13; ++i) {
        if (liste_valeur[j.cartes[i].valeur] == 12 && !j.cartes[i].util) {
            twelve_found = true;
            douz = i;
            break;
        }
    }

    // recherche roi non utilisé
    for (int i = 0; i < 13; ++i) {
        if (liste_valeur[j.cartes[i].valeur] == 13 && !j.cartes[i].util) {
            thirteen_found = true;
            traiz = i;
            break;
        }
    }



    if (twelve_found && thirteen_found && as_found) {
        if (j.cartes[douz].type == j.cartes[traiz].type && j.cartes[traiz].type == j.cartes[as_index].type) {
            for (int i = 0; i < 14; ++i) {
                if (j.suite[i].valeur == "") {
                    j.suite[i] = j.cartes[douz];
                    j.suite[i + 1] = j.cartes[traiz];
                    j.suite[i + 2] = j.cartes[as_index];
                    j.cartes[douz].util = true;
                    j.cartes[traiz].util = true;
                    j.cartes[as_index].util = true;
                    break;
                }
            }
        }
    }


}

void afficher_cartes_non_utilisé(joueur j){
    std::cout<<"les cartes non utilisées sont les suivantes ! : "<< std::endl;
    for (int i = 0; i < 14; ++i) {
        if (!j.cartes[i].util)
        std::cout << j.cartes[i].valeur << " " << j.cartes[i].type << " " <<  "|";
    }
    std::cout << std::endl;
}



void reinitialiser_jeu_defausse(carte*& jeu, carte*& defausse_pile) {
    if (jeu != nullptr) {
        delete[] jeu; 
        jeu = nullptr; 
    }

    if (defausse_pile != nullptr) {
        delete[] defausse_pile; 
        defausse_pile = nullptr; 
    }
}

void reinitialiser_combinaisons(joueur& j) {
    for (int k = 0; k < 14; ++k) {
        j.suite[k] = {"", "", false};
        j.brelan[k] = {"", "", false};
        j.carre[k] = {"", "", false};
        j.paire[k] = {"", "", false};
        j.cartes[k].util = false;
    }
}

void reinitialiser_cartes_util(joueur& j) {
    for (int i = 0; i < 13; ++i) {
        j.cartes[i].util = false;
    }
}


bool est_carte_morte(int val, std::string type, defausse defausse_pile) {
//une carte morte est une carte qui est passée deux fois dans la défausse
    int cpt = 0;
    
    defausse current = defausse_pile;
    while (current != nullptr) {
        if (liste_valeur[current->crt.valeur] == val && current->crt.type == type) {
            cpt++;
        }
        current = current->suiv;
    }
    
    return (cpt == 2);
}


carte_tab* proposer_defausse(joueur& j, defausse& defausse_pile, int& taille_prop_defausse) {
    trier_liste(j, 13);  // Trier les cartes du joueur
    liste_carre(j);      // Identifier les carrés
    liste_suite(j);     // Identifier les tierces
    liste_brelan(j);     // Identifier les brelans
    carte_tab* prop_defausse = new carte_tab[14]; // Tableau pour stocker les cartes proposées
    int cpt = 0;
    bool avant, apres, milieu;

    // Identifier les paires consécutives
    for (int i = 0; i < 13; ++i) {
        if ( j.cartes[i].type == j.cartes[i + 1].type &&
            liste_valeur[j.cartes[i].valeur] == liste_valeur[j.cartes[i + 1].valeur]) {
            prop_defausse[cpt++] = j.cartes[i];
            j.cartes[i].util = true;
            j.cartes[i + 1].util = true;
        }
    }

    // Identifier les tierces non completé 
    for (int i = 0; i < 13; ++i) {
        if (j.cartes[i].util) continue;

        for (int y = i + 1; y < 14; ++y) {
            if (j.cartes[y].util) continue;

            if (liste_valeur[j.cartes[i].valeur] + 1 == liste_valeur[j.cartes[y].valeur] &&
                j.cartes[i].type == j.cartes[y].type) {
                avant = est_carte_morte(liste_valeur[j.cartes[i].valeur] - 1, j.cartes[i].type, defausse_pile);
                apres = est_carte_morte(liste_valeur[j.cartes[y].valeur] + 1, j.cartes[i].type, defausse_pile);

                if (avant && apres) {
                    j.cartes[i].util = true;
                    j.cartes[y].util = true;
                    prop_defausse[cpt++] = j.cartes[i];
                    prop_defausse[cpt++] = j.cartes[y];
                }
            }
        }
    }

    // Identifier les tierces avec une carte manquante au milieu
    for (int i = 0; i < 12; ++i) {
        if (j.cartes[i].util) continue;

        for (int y = i + 1; y < 13; ++y) {
            if (j.cartes[y].util) continue;

            if (liste_valeur[j.cartes[i].valeur] + 2 == liste_valeur[j.cartes[y].valeur] &&
                j.cartes[i].type == j.cartes[y].type) {
                milieu = est_carte_morte(liste_valeur[j.cartes[i].valeur] + 1, j.cartes[i].type, defausse_pile);
                if (milieu) {
                    j.cartes[i].util = true;
                    j.cartes[y].util = true;
                    prop_defausse[cpt++] = j.cartes[i];
                    prop_defausse[cpt++] = j.cartes[y];
                }
            }
        }
    }

    reinitialiser_cartes_util(j);
    taille_prop_defausse = cpt; // Retourner la taille du tableau
    return prop_defausse;
}

int position(joueur j, int valeur, std::string type) {
    for (int i = 0; i < 14; ++i) {
        if (liste_valeur[j.cartes[i].valeur] == valeur && j.cartes[i].type == type) {
            return i + 1;
        }
    }
    return -1; // Retourner -1 si la carte n'est pas trouvée
}


void defausser_carte(joueur& j, defausse& defausse_pile, const carte_tab& carte_piochee) {
    int p;
    int taille_prop_defausse = 0; // Taille du tableau de cartes proposées
    carte_tab* propo = proposer_defausse(j, defausse_pile, taille_prop_defausse);
    
    do {
       if (propo[0].type != "") {
            std::cout << j.nom << ", entrez une position entre 1 et 14 de la carte à défausser, nous vous proposons les cartes suivantes : " << std::endl;
            for (int i = 0; i < taille_prop_defausse; ++i) {
                std::cout << propo[i].valeur << " " << propo[i].type <<" à la position "<< position(j,liste_valeur[propo[i].valeur],propo[i].type)<< " | ";
            }
        }
        else
        std::cout << j.nom << ", nous n'avons aucune carte à vous proposer :( entrez une position entre 1 et 14 de la carte à défausser : " << std::endl;
        

        std::cin >> p;
    } while (p < 1 || p > 14);

    carte* nouvelle_defausse = new carte;
    nouvelle_defausse->crt = j.cartes[p - 1];
    nouvelle_defausse->suiv = defausse_pile;
    defausse_pile = nouvelle_defausse;

    j.cartes[p - 1] = carte_piochee;

    std::cout << "Carte défaussée avec succès !" << std::endl;

    delete[] propo; // Libérer la mémoire allouée pour les cartes proposées
}



void afficher_combi(joueur& j) {
    // Affichage des Carrés
    liste_carre(j);
    std::cout << "Carrés : ";
    bool carre_trouve = false;
    for (int k = 0; k < 14; ++k) {
        if (j.carre[k].valeur != "") {
            carre_trouve = true;
            std::cout << j.carre[k].valeur <<" "<< j.carre[k].type << " | ";
        }
    }
    if (!carre_trouve) {
        std::cout << "Aucun carré trouvé";
    }
    std::cout << std::endl ;

    // Affichage des Suites
    liste_suite(j);
    completer_as(j);
    std::cout << "Suites : ";
    bool suite_trouvee = false;
    for (int k = 0; k < 14; ++k) {
        if (j.suite[k].valeur != "") {
            suite_trouvee = true;
            std::cout << j.suite[k].valeur <<" "<< j.suite[k].type << " | ";
        }
    }
    if (!suite_trouvee) {
        std::cout << "Aucune suite trouvée";
    }
    std::cout << std::endl ;

    // Affichage des Brelans
    liste_brelan(j);
    std::cout << "Brelans : ";
    bool brelan_trouve = false;
    for (int k = 0; k < 14; ++k) {
        if (j.brelan[k].valeur != "") {
            brelan_trouve = true;
            std::cout << j.brelan[k].valeur <<" "<< j.brelan[k].type << " | ";
        }
    }
    if (!brelan_trouve) {
        std::cout << "Aucun brelan trouvé";
    }
    std::cout << std::endl ;
}








void verifier_choix(joueur& j) {
    char choix;
    char c1, c2;
    std::cout << "Ces combinaisons vous plaisent-elles ? (O pour oui, N pour non) : ";
    
    // Lecture de l'entrée utilisateur avec vérification des choix valides
    
    while (true) {
        std::cin >> choix;
        if (choix == 'o' || choix == 'O' || choix == 'n' || choix == 'N') {
            break;
        } else {
            std::cout << "Veuillez entrer O pour oui ou N pour non : ";
        }
    }

    if (choix == 'N' || choix == 'n') {
        std::cout << "Veuillez saisir la combinaison (première initiale) de laquelle vous souhaitez retirer la carte, ainsi que la combinaison (première initiale) dans laquelle vous souhaitez l'affecter." << std::endl;
        std::cin >> c1 >> c2;

        if (c1 == 'c' && c2 == 's') {
            reinitialiser_cartes_util(j);
            liste_suite(j);
            liste_carre(j);
            liste_brelan(j);
        }
        if (c1 == 's' && c2 == 'b') {
            reinitialiser_cartes_util(j);
            liste_carre(j);
            liste_brelan(j);
            liste_suite(j);
        }
        if (c1 == 'c' && c2 == 'b') {
            reinitialiser_cartes_util(j);
            liste_brelan(j);
            liste_suite(j);
            liste_carre(j);
        }
        afficher_combi(j);
        
    }
    

}





int calculer_points_joueur(const joueur& j) {
    int points = 0;
    bool dernier_brelan_est_roi = false;

    // Calculer les points des cartes
    for (int i = 0; i < 14; ++i) {
        if (j.cartes[i].valeur != "") {
            points += liste_valeur[j.cartes[i].valeur];
        }
    }

    // Vérifier si la dernière carte du tableau brelan est un As ( il sera considéré comme un 14, et comme on la calculé etant 1 il suffit d'ajouter 13 )
    if (j.brelan[13].valeur == "As") {
        points += 13;
    }

    return points;
}






int main() {
    int manches; 
    std::cout << "Veuillez saisir le nombre de manches : ";
    std::cin >> manches;

    int nbr;
    do {
        std::cout << "Entrez le nombre de joueurs (entre 2 et 6) : ";
        std::cin >> nbr;
    } while (nbr < 2 || nbr > 6);

    joueur* tab_joueur;
    tab_joueur = new joueur[nbr];

    for (int i = 0; i < nbr; ++i) {
        std::cout << "Entrez le nom du joueur " << i + 1 << " : ";
        std::cin >> tab_joueur[i].nom;
    }

    for (int m = 0; m < manches; ++m) { 
        std::cout << "Manche " << m + 1 << std::endl;
        Jeu jeu = CreeJeu();
        defausse defausse_pile = nullptr;

        distribuer(jeu, nbr, tab_joueur);

        initialiser_defausse(jeu, defausse_pile);

        bool manche_terminee = false; 
        while (!manche_terminee) {
            for (int i = 0; i < nbr; ++i) {
                trier_liste(tab_joueur[i], 13);
                afficher_cartes_joueur(tab_joueur[i]);
                afficher_cartes_joueur_organiser(tab_joueur[i]);
                std::cout << tab_joueur[i].nom << ", c'est à votre tour de piocher puis de défausser une carte ! " << std::endl;
                trier_liste(tab_joueur[i], 13);

                carte_tab carte_piochee = piocher_carte(jeu, defausse_pile);
                defausser_carte(tab_joueur[i], defausse_pile, carte_piochee);
                
                std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
                afficher_combi(tab_joueur[i]);
                std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
                verifier_choix(tab_joueur[i]);
                afficher_cartes_non_utilisé(tab_joueur[i]);
                std::cout<<std::endl;
                std::cout << "___________________________________________________________________________________________________" << std::endl;
                std::cout<<std::endl;
                

                int cmb = nombre_total_cartes(tab_joueur[i]);

                if (cmb == 14) {
                    std::cout << "Félicitations ! " << tab_joueur[i].nom << " est le gagnant de la manche " << m + 1 << " !" << std::endl;
                    manche_terminee = true;
                    break;
                }
                
                reinitialiser_combinaisons(tab_joueur[i]);
            }
        }

        // Calculer et afficher les points de chaque joueur après chaque manche
        std::cout << "Points après la manche " << m + 1 << ":" << std::endl;
        for (int i = 0; i < nbr; ++i) {
            int points = calculer_points_joueur(tab_joueur[i]);
            std::cout << tab_joueur[i].nom << ": " << points << " points" << std::endl;
        }

        reinitialiser_jeu_defausse(jeu, defausse_pile);
    }
  
    delete[] tab_joueur; // libérer la mémoire allouée dynamiquement
    return 0;
}


