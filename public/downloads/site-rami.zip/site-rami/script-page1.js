let section_combi = document.getElementById("combinaison");
let footer = document.getElementById("footer");
let section_regles = document.getElementById("regles");

document.addEventListener("DOMContentLoaded", function() {

    window.addEventListener("scroll", function() {
        let positionFromTop = section_combi.getBoundingClientRect().top;
        const screenHeight = window.innerHeight;

        if (positionFromTop - screenHeight <= 0) {
            section_combi.classList.add("animate-slide-up");
        }

        positionFromTop = footer.getBoundingClientRect().top;

        if (positionFromTop - screenHeight <= 0) {
            footer.classList.add("animate-slide-up");
        }

        positionFromTop = section_regles.getBoundingClientRect().top;

        if (positionFromTop - screenHeight <= 0) {
            section_regles.classList.add("animate-slide-up");
        }

    });
});