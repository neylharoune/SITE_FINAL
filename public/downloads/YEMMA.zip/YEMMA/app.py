from flask import Flask, render_template, request, jsonify
from flask_mail import Mail, Message
from datetime import datetime

app = Flask(__name__)

# --- CONFIGURATION EMAIL (À remplir comme vu précédemment) ---
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'neylaharoune722@gmail.com'
app.config['MAIL_PASSWORD'] = 'iqar bpha ltut vuxa'
app.config['MAIL_DEFAULT_SENDER'] = 'neylaharoune722@gmail.com'

mail = Mail(app)

# CONFIGURATION DU RESTO
TABLES_CONFIG = {
    "DUO": {"capacite": 2, "total": 10},
    "QUATRO": {"capacite": 4, "total": 5},
    "FAMILLE": {"capacite": 6, "total": 2}
}

reservations_db = {}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/verifier_disponibilite', methods=['POST'])
def verifier():
    data = request.json
    dt_str = data.get('date_heure') # Format attendu: "YYYY-MM-DDTHH:MM"
    nb = int(data.get('nb_personnes'))
    
    # Conversion de la chaîne en objet datetime
    dt_obj = datetime.strptime(dt_str, '%Y-%m-%dT%H:%M')
    heure = dt_obj.hour
    jour = dt_obj.weekday() # 0 = Lundi, 6 = Dimanche

    # 1. Vérification du Dimanche
    if jour == 6:
        return jsonify({"status": "complet", "message": "Le restaurant est fermé le dimanche."})

    # 2. Vérification des horaires (Midi: 12h-14h | Soir: 19h-22h)
    # Note: On accepte jusqu'à 13h45 et 21h45 pour laisser le temps de manger
    is_midi = (12 <= heure < 14)
    is_soir = (19 <= heure < 22)

    if not (is_midi or is_soir):
        return jsonify({"status": "complet", "message": "Hors horaires d'ouverture (12h-14h / 19h-22h)."})

    # 3. Logique de sélection de table
    t_type = "DUO" if nb <= 2 else "QUATRO" if nb <= 4 else "FAMILLE"
    
    if dt_str not in reservations_db:
        reservations_db[dt_str] = {"DUO": 0, "QUATRO": 0, "FAMILLE": 0}

    if reservations_db[dt_str][t_type] < TABLES_CONFIG[t_type]["total"]:
        return jsonify({"status": "disponible", "table": t_type})
    else:
        return jsonify({"status": "complet", "message": "Plus de tables disponibles pour ce créneau."})

@app.route('/confirmer_reservation', methods=['POST'])
def confirmer():
    # ... (Le reste du code de confirmation reste identique) ...
    data = request.json
    nom = data.get('nom')
    dt = data.get('date_heure')
    t_type = data.get('table_type')
    
    if dt not in reservations_db:
        reservations_db[dt] = {"DUO": 0, "QUATRO": 0, "FAMILLE": 0}
    reservations_db[dt][t_type] += 1

    try:
        msg = Message("Nouvelle Réservation Yemma !", recipients=["neylaharoune722@gmail.com"])
        msg.body = f"Nouvelle résa :\n- Client : {nom}\n- Date/Heure : {dt}\n- Type : {t_type}"
        mail.send(msg)
        return jsonify({"status": "success", "message": "Réservation confirmée et email envoyé !"})
    except Exception as e:
        return jsonify({"status": "error", "message": f"Erreur email : {str(e)}"})

if __name__ == '__main__':
    app.run(debug=True)